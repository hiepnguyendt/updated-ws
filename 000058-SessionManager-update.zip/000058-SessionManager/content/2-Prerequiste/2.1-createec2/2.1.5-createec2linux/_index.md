---
title : "Create Public instance"
date : "`r Sys.Date()`"
weight : 5
chapter : false
pre : " <b> 2.1.5 </b> "
---

#### Create Public EC2 Linux

You refer to how to create [EC2 Linux](https://000004.awsstudygroup.com/4-launchlinuxinstance/)

1. Go to [EC2 service management console](https://console.aws.amazon.com/ec2/v2/home)
  - Navigate to **EC2**
  - Click on **Instances**
  
![EC2](/images/2.prerequisite/027-createec2.png)

2. In the **Launch an instance** interface:
  - Select **Instances**
  - Choose **Launch instances**
  - Type enter **```Public Linux Instance```**

![EC2](/images/2.prerequisite/028-createec2.png)

3. Select an **Instance type** and opt to **Create a new key pair**
 
![EC2](/images/2.prerequisite/029-createec2.png)

4. At **Step 3: Configure Instance Details** page
  - Specify the **Key pair name**, e.g., **```linux-ec2-key```** (optional name, you can set any).
  - Choose **Key pair type: RSA**
  - Select **Private key file format: .pem**

![EC2](/images/2.prerequisite/030-createec2.png)

5. Configure the **Network**:

    - Select the **VPC**: **Lab VPC**
    - Choose the **Subnet**: **Lab Public Subnet**
    - Enable **Auto-assign public IP**
    - For **Firewall (Security Group)**, select **Select existing security group**
    - Choose **SG Public Linux Instance**
    - Click **Launch instance**

![EC2](/images/2.prerequisite/031-createec2.png)

6. Complete the instance creation

![EC2](/images/2.prerequisite/032-createec2.png)

Next, we will do the same to create an EC2 Instance Windows running in the Private subnet.