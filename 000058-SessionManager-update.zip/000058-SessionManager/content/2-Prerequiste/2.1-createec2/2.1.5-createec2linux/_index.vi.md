---
title : "Tạo Public Linux EC2"
date :  "`r Sys.Date()`" 
weight : 5
chapter : false
pre : " <b> 2.1.5 </b> "
---

#### Tạo Public EC2 Linux

Bạn tham khảo cách tạo [EC2 Linux](https://000004.awsstudygroup.com/4-launchlinuxinstance/)

1. Truy cập [giao diện quản trị dịch vụ EC2](https://console.aws.amazon.com/ec2/v2/home)
  - Giao diện ở **EC2**
  - Click on **Instances**
  
![EC2](/images/2.prerequisite/027-createec2.png)

2. Trong giao diện **Launch an instance**:
  - Chọn **Instances**
  - Chọn **Launch instances**
  - Nhập tên **```Public Linux Instance```**
  
![EC2](/images/2.prerequisite/028-createec2.png)

3. Chọn một loại **Instance type** và tạo **Create a new key pair**
 
![EC2](/images/2.prerequisite/029-createec2.png)

4. Specify the **Key pair name**, e.g., **```linux-ec2-key```** (tên tùy chọn, bạn có thể đặt bất kỳ tên nào).
  - Chọn **Key pair type: RSA**
  - Chọn **Private key file format: .pem**

![EC2](/images/2.prerequisite/030-createec2.png)

5. Thiết lập cấu hình **Network**:

    - Chọn **VPC**: **Lab VPC**
    - Chọn **Subnet**: **Lab Public Subnet**
    - Bật **Auto-assign public IP**
    - Đối với **Firewall (Security Group)**, chọn **Select existing security group**
    - Chọn **SG Public Linux Instance**
    - Chọn **Launch instance**

![EC2](/images/2.prerequisite/031-createec2.png)

6. Hoàn thành tạo instance

![EC2](/images/2.prerequisite/032-createec2.png)

Tiếp theo chúng ta sẽ thực hiện tương tự để tạo 1 EC2 Instance Windows chạy trong Private subnet.