---
title : "Tạo Private Windows EC2"
date :  "`r Sys.Date()`" 
weight : 6
chapter : false
pre : " <b> 2.1.6 </b> "
---

#### Tạo Private EC2 Windows

Bạn tham khảo cách tạo [EC2 Windows](https://000004.awsstudygroup.com/3-launchwindowsinstance/)

1. Truy cập [giao diện quản trị dịch vụ EC2](https://console.aws.amazon.com/ec2/v2/home)
  - Giao diện ở **EC2**
  - Click on **Instances**
  
![EC2](/images/2.prerequisite/034-createec2.png)

2. Trong giao diện **Launch an instance**:
  - Chọn **Instances**
  - Chọn **Launch instances**
  - Nhập tên **```Public Linux Instance```**
  
![EC2](/images/2.prerequisite/035-createec2.png)

3. Chọn một type **Instance type** và Key pair name: **linux-ec2-key**
 
![EC2](/images/2.prerequisite/036-createec2.png)

4. Thiết lập cấu hình **Network**:

    - Chọn **VPC**: **Lab VPC**
    - Chọn **Subnet**: **Lab Public Subnet**
    - Bật **Auto-assign public IP**
    - Đối với **Firewall (Security Group)**, chọn **Select existing security group**
    - Chọn **SG Public Linux Instance**
    - Chọn **Launch instance**

![EC2](/images/2.prerequisite/037-createec2.png)

5. Hoàn thành tạo instance

![EC2](/images/2.prerequisite/038-createec2.png)

Tiếp theo chúng ta sẽ tiến hành tạo các IAM Role để phục vụ cho Session Manager.