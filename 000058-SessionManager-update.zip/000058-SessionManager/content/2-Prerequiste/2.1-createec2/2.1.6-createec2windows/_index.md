---
title : "Create Private Instance"
date : "`r Sys.Date()`"
weight : 6
chapter : false
pre : " <b> 2.1.6 </b> "
---

#### Create Private EC2 Windows

You refer to how to create [EC2 Windows](https://000004.awsstudygroup.com/3-launchwindowsinstance/)

1. Go to [EC2 service management console](https://console.aws.amazon.com/ec2/v2/home)
  - Navigate to **EC2**
  - Click on **Instances**
  
![EC2](/images/2.prerequisite/034-createec2.png)

2. In the **Launch an instance** interface:
  - Select **Instances**
  - Choose **Launch instances**
  - Type enter **```Public Linux Instance```**

![EC2](/images/2.prerequisite/035-createec2.png)

3. Select an **Instance type** and choose Key pair name **linux-ec2-key**

![EC2](/images/2.prerequisite/036-createec2.png)

4. Configure the **Network**:

    - Select the **VPC**: **Lab VPC**
    - Choose the **Subnet**: **Lab Private Subnet 1**
    - Enable **Auto-assign public IP**
    - For **Firewall (Security Group)**, select **Select existing security group**
    - Choose **SG Private Windows Instance**
    - Click **Launch instance**

![EC2](/images/2.prerequisite/037-createec2.png)

5. Complete the instance creation

![EC2](/images/2.prerequisite/038-createec2.png)

Next, we will proceed to create IAM Roles to serve the Session Manager.