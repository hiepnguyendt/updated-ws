---
title : "Create IAM Role"
date : "`r Sys.Date()`"
weight : 2
chapter : false
pre : " <b> 2.2 </b> "
---

### Create IAM Role

In this step, we will proceed to create IAM Role. In this IAM Role, the policy **AmazonSSMManagedInstanceCore** will be assigned, this is the policy that allows the EC2 server to communicate with the Session Manager.

1. Go to [IAM service administration interface](https://console.aws.amazon.com/iamv2/)

2. In the left navigation bar, click **Roles** and click **Create role**.

![role](/images/2.prerequisite/038-iamrole.png)

3. In the **Select trusted entity** interface
  - Choose **AWS sevice**
  - For **Service or use case**, choose **EC2**
  - Choose a use case for the specified service as **EC2**
  - Click Next

![role1](/images/2.prerequisite/039-iamrole.png)

7. Name the Role **SSM-Role** in Role Name

![createpolicy](/images/2.prerequisite/041-iamrole.png)

8. Finshed to **Create Role**.

![namerole](/images/2.prerequisite/042-iamrole.png)

Next, we will make the connection to the EC2 servers we created with **Session Manager**.