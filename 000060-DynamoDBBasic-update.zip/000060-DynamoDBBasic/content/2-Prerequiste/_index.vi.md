---
title : "Các bước chuẩn bị"
date :  "`r Sys.Date()`" 
weight : 2
chapter : false
pre : " <b> 2. </b> "
---

{{% notice info %}}
Bạn cần tạo sẵn 1 Access key để tiến hành cấu hình AWS CLI.
{{% /notice %}}
Bạn có thể truy cập AWS DynamoDB bằng cách sử dụng AWS Management Console, AWS Command Line Interface (AWS CLI).

### Nội dung
  - [Sử dụng AWS Management Console](2.1-useawsmanagementconsole/)
  - [Sử dụng AWS CloudShell](2.2-useawscloudshell/)
