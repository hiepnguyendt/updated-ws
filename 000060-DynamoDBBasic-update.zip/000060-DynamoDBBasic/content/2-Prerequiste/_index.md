---
title : "Preparation "
date : "`r Sys.Date()`"
weight : 2
chapter : false
pre : " <b> 2. </b> "
---

{{% notice info %}}
You need to create an Access key to proceed with the AWS CLI configuration.
{{% /notice %}}
You can access AWS DynamoDB using the AWS Management Console, AWS Command Line Interface (AWS CLI).

### Content
   - [Using AWS Management Console](2.1-useawsmanagementconsole/)
   - [Using AWS CloudShell](2.2-useawscloudshell/)
