---
title : "Amazon DynamoDB"
date :  "`r Sys.Date()`" 
weight : 1
chapter : false
---
# Làm việc với Amazon DynamoDB

### Tổng quan

 Trong bài lab này, bạn sẽ tìm hiểu các khái niệm cơ bản và thực hành về Amazon DynamoDB. Thực hành Python với Amazon DynamoDB.

![Query](/images/1-introduce/1.4-namingrulesanddatatypes/0001-Diagram-Base-Table.png)

### Nội dung

 1. [Giới thiệu](1-introduce)
 2. [Các bước chuẩn bị](2-prerequiste/)
 3. [Bắt đầu với AWS SDK](3-gettingstartedwithawssdk/)
 4. [Dọn dẹp tài nguyên](4-cleanupresource/)
