---
title : "Chuẩn bị"
date :  "`r Sys.Date()`" 
weight : 2
chapter : false
pre : " <b> 2. </b> "
---

#### Tổng quan

Trước khi thực hành, ta khởi tạo một số mục liên quan sau đây: tạo Access Key, cài đặt và cấu hình AWS CLI.

**Nội dung:**
- [2.1. Tạo AWS Access Key](2.1-create-accesskey/)
- [2.2. Cài đặt AWS CLI](2.2-install-aws-cli/)
- [2.3. Cấu hình AWS CLI](2.3-configure-aws-cli/)
