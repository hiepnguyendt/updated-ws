---
title : "Connecting to Elasticache"
date : "`r Sys.Date()`"
weight : 2
chapter : false
pre : " <b> 4.2 </b> "
---

### Overview

The following lab uses the Redis client to connect to ElastiCache.

### Content

- [Connect to a cluster (cluster mode disable)](4.2.1-connecting-to-a-cluster-mode-disabled-cluster/)
- [Connect to a cluster (cluster mode enable)](4.2.2-connecting-to-a-cluster-mode-enabled-cluster/)