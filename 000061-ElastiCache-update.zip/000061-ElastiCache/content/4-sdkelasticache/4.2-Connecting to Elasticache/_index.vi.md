---
title : "Kết nối với Elasticache"
date :  "`r Sys.Date()`" 
weight : 2
chapter : false
pre : " <b> 4.2 </b> "
---

### Tổng quan

Bài lab sau sử dụng ứng dụng khách Redis để kết nối với ElastiCache.

### Nội dung 

- [Kết nối tới một cluster (cluster mode disable)](4.2.1-connecting-to-a-cluster-mode-disabled-cluster/)
- [Kết nối tới một cluster (cluster mode enable)](4.2.2-connecting-to-a-cluster-mode-enabled-cluster/)