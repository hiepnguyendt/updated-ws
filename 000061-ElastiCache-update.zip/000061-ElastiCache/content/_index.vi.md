---
title : "Amazon ElastiCache - Redis"
date :  "`r Sys.Date()`" 
weight : 1 
chapter : false
---
#  Amazon ElastiCache - Redis 

### Tổng quan

 Trong bài lab này, bạn sẽ tìm hiểu các khái niệm cơ bản và thực hành về Amazon ElastiCache  - Redis.


### Nội dung

 1. [Giới thiệu](1-introduce/)
 2. [Các bước chuẩn bị](2-prerequiste/)
 3. [Tạo ElastiCache cluster](3-amazonelasticacheforredis/)
 4. [Sử dụng AWS SDK để ghi và đọc tới ElastiCache](4-sdkelasticache/)
 5. [Dọn dẹp tài nguyên](5.cleanupresource/)
