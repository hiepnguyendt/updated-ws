---
title : "Xóa cluster"
date :  "`r Sys.Date()`" 
weight : 6
chapter : false
pre : " <b> 3.6 </b> "
---

Quy trình sau đây xóa một cluster đơn lẻ khỏi triển khai của bạn. Để xóa nhiều cluster, hãy lặp lại quy trình cho từng cluster mà bạn muốn xóa. Bạn không cần phải đợi một cluster hoàn thành xóa trước khi bắt đầu quy trình xóa một cluster khác.

### Nội dung

- [3.6.1 Xóa cluster sử dụng Console](3.6.1-use-console/)
- [3.6.2 Xóa cluster sử dụng AWS CLI](3.6.2-use-aws-cli/)