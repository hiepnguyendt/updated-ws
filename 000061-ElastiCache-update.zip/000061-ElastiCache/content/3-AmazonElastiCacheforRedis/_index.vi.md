---
title : "Tạo ElastiCache cluster"
date :  "`r Sys.Date()`" 
weight : 3
chapter : false
pre : " <b> 3. </b> "
---

### Nội dung
- [Tạo một subnet group](3.1-create-a-subnet-group/)
- [Tạo một cluster (cluster-mode-disabled)](3.2-create-a-clustercluster-mode-disabled/)
- [Tạo một cluster (cluster-mode-enabled)](3.3-create-a-clustercluster-mode-enabled/)
- [Cấp quyền truy cập cluster](3.4-grantaccesstocluster/)
- [Kết nối các node của cluster](3.5-connect-to-the-clusters-node/)
- [Xóa một cluster](3.6-deleting-a-cluster/)