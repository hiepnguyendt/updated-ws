+++
title = "Dọn dẹp tài nguyên  "
weight = 4
chapter = false
pre = "<b>4. </b>"
+++

Chúng ta sẽ tiến hành xóa các tài nguyên theo thứ tự sau 

1. Tại giao diện quản trị của Cloud9.
  + Click chọn Cloud9 instance mà bạn đã tạo.
  + Click **Delete**.

![Cloud9](/images/cloud9/3/1.png?width=90pc)

2. Điền **Delete** vào để xác nhận.
  + Click **Delete** để xóa Cloud9 instance đã tạo.

 
![Cloud9](/images/cloud9/3/2.png?width=90pc)