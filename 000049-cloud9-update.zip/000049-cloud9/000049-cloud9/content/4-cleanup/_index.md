+++
title = "Clean up resources"
weight = 5
chapter = false
pre = "<b>5. </b>"
+++

We will proceed to delete the resources in the following order

1. At the administration interface of Cloud9.
   + Click on the Cloud9 instance you created.
   + Click **Delete**.
![Cloud9](/images/cloud9/3/1.png?width=90pc)

2. Enter **Delete** to confirm.
   + Click **Delete** to delete the created Cloud9 instance.
![Cloud9](/images/cloud9/3/2.png?width=90pc)