+++
title = "Tạo Cloud9 instance"
weight = 2
chapter = false
pre = "<b>2. </b>"
+++

#### Tạo Cloud9 instance.

Trong bước này, chúng ta sẽ truy cập vào giao diện quản trị dịch vụ Cloud9 và tiến hành tạo 1 Cloud9 instance.

1. Click vào khung tìm kiếm , gõ **Cloud9**.
  + Click vào biểu tượng **Cloud9** để đi đến giao diện quản trị Cloud9.

![Cloud9](/images/cloud9/1/5.png?width=90pc)

2. Tại giao diện quản trị Cloud9.
  + Click **Create environment**.

![Cloud9](/images/cloud9/1/6.png?width=90pc)

3. Tại trang **Details**.
  + Đặt tên Cloud9 instance của bạn.
    + Mục **Enviroment type**, Mục **New EC2 instance**
  + Mục **New EC2 type**
    + Instance type : Mục **t2.micro**.
    + Platform : Mục **Amazon Linux2**.

![Cloud9](/images/cloud9/1/7.png?width=90pc)

4. Kéo màn hình xuống
  + Platform : Chọn **Amazon Linux2**.
  + Chọn **After 30 minutes**. Cho phép tự động stop Cloud9 instance để tiết kiệm chi phí.

![Cloud9](/images/cloud9/1/8.png?width=90pc)

5. Kéo màn hình xuống
  + Chọn **VPC Setting**
    + Chọn **cloud9-vpn**   
    + Chọn **cloud9-vpn-subnet-public...**

![Cloud9](/images/cloud9/1/9.png?width=90pc)

6. Tại trang **Review**.
  + Kiểm tra cấu hình đã chọn.
  + Kéo xuống cuối trang, click **Create environment**.

7. Sẽ mất vài phút để Cloud9 Instance được khởi tạo.

![Cloud9](/images/cloud9/1/10.png?width=90pc)

8. Click biểu tượng close để đóng tab **Welcome** và **AWS Toolkit** nếu không cần sử dụng.

![Cloud9](/images/cloud9/1/11.png?width=90pc)

Chúc mừng bạn đã hoàn thành việc tạo Cloud9 instance, trong các bước tiếp theo chúng ta sẽ thử thực hiện 1 số thao tác cơ bản trên Cloud9.