+++
title = "Create Cloud9 instance"
weight = 2
chapter = false
pre = "<b>2. </b>"
+++

#### Create Cloud9 instance.

In this step, we will access the Cloud9 service administration interface and proceed to create a Cloud9 instance.

1. Click on the search box, type **Cloud9**.
  - Click on **Cloud9** icon to go to Cloud9 admin interface.
  ![Cloud9](/images/cloud9/1/5.png?width=90pc)

2. At the Cloud9 admin interface.
- Click **Create environment**.
  ![Cloud9](/images/cloud9/1/6.png?width=90pc)

3. At **Details** page.
  - Name your Cloud9 instance.
    - Example: **cloud9instance**.
    - Section **Enviroment type**, select **New EC2 instance**
  - Section **New EC2 type**
    - Instance type : Select **t2.micro**.
![Cloud9](/images/cloud9/1/7.png?width=90pc)

4. Drag down the screen 
  - Platform : Select **Amazon Linux2**.
  - Select **Timeout 30 minutes**. Allows to automatically stop Cloud9 instances to save costs.

![Cloud9](/images/cloud9/1/8.png?width=90pc)

5. Drag down the screen
  - Select **VPC Setting**
    - Select **cloud9-vpn**   
    - Select **cloud9-vpn-subnet-public...**

![Cloud9](/images/cloud9/1/9.png?width=90pc)

6. At **Review** page.
  - Check the selected configuration.
  - Scroll to the bottom of the page, click **Create environment**.

7. It will take a few minutes for Cloud9 Instance to be initialized.

![Cloud9](/images/cloud9/1/10.png?width=90pc)

8. Click the close icon to close the **Welcome** and **AWS Toolkit** tabs if not needed.

![Cloud9](/images/cloud9/1/11.png?width=90pc)

Congratulations on completing the creation of Cloud9 instance, in the next steps we will try to perform some basic operations on Cloud9.