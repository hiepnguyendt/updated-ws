+++
title = "Làm việc với file text"
weight = 2
chapter = false
pre = "<b>3.2 </b>"
+++

#### Làm việc với file text

Trong bước này chúng ta sẽ thực hiện tạo và chỉnh sửa các file text, file mã nguồn trên Cloud9.

1. Tại giao diện cây thư mục bên trái, click chuột phải vào file **README.md** và click **Open**.

![Cloud9](/images/cloud9/2/5.png?width=90pc)

2. Bạn sẽ thấy file README.md đã được mở ra.
  + Hãy gõ thêm 1 đoạn text vào như hình dưới.
  + VD : It is easy to edit text in Cloud9.

  
![Cloud9](/images/cloud9/2/6.png?width=90pc)

3. Sau khi chỉnh sửa xong, bạn có thể ấn tổ hợp phím **Ctrl + S** để save file lại. Hoặc click vào menu **File**>**Save**.

![Cloud9](/images/cloud9/2/7.png?width=90pc)

4. Việc tạo file mới cũng hết sức đơn giản.Click vào menu **File**>**New From Template** > tùy chọn dạng file text / mã nguồn mà bạn muốn tạo.

![Cloud9](/images/cloud9/2/8.png?width=90pc)

