+++
title = "Working with text files"
weight = 2
chapter = false
pre = "<b>3.2 </b>"
+++

#### Working with text files

In this step, we will create and edit text files, and source code files on Cloud9.

1. At the left directory tree interface, right-click the **README.md** file and click **Open**.

![Cloud9](/images/cloud9/2/5.png?width=90pc)

2. You should see the README.md file opened.
  + Please type 1 more text in as shown below.
  + Example: It is easy to edit text in Cloud9.

  
![Cloud9](/images/cloud9/2/6.png?width=90pc)

3. After editing, you can press the key combination **Ctrl + S** to save the file. Or click on the menu **File**>**Save**.

![Cloud9](/images/cloud9/2/7.png?width=90pc)

4. Creating a new file is also very simple. Click on the menu **File**>**New From Template** > option the text file / source code you want to create.

![Cloud9](/images/cloud9/2/8.png?width=90pc)