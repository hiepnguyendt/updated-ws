+++
title = "Tính năng cơ bản"
weight = 3
chapter = false
pre = "<b>3. </b>"
+++

#### Sử dụng tính năng cơ bản của Cloud9

Trong bước này, chúng ta sẽ sử dụng 1 số tính năng cơ bản của Cloud9 có sử dụng trong các bài lab của Cloud Journey.

#### Nội Dung

1. [Sử dụng command line](2.1-runcommand/)
2. [Làm việc với file text](2.2-edittext/)
3. [Quay lại giao diện Dashboard](2.3-backtodashboard/)