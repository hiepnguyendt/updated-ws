+++
title = "Basic Features"
weight = 3
chapter = false
pre = "<b>3. </b>"
+++

#### Using Cloud9 Basic Features

In this step, we will use some of the basic Cloud9 features that are used in the Cloud Journey labs.

#### Content

1. [Using command line](2.1-runcommand/)
2. [Working with text files](2.2-edittext/)
3. [Back to Dashboard interface](2.3-backtodashboard/)