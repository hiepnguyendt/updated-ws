+++
title = "Using command line"
date = 2021
weight = 1
chapter = false
pre = "<b>3.1 </b>"
+++

#### Using command line

In this step, we will use the terminal interface and perform basic Linux command lines on the Cloud9 instance.

1. At the Cloud9 IDE interface, click the + icon.
  + Click **New Terminal**.
![Cloud9](/images/cloud9/2/1.png?width=90pc)

2. We will see Cloud9 open a terminal interface that allows us to execute Linux commands.
![Cloud9](/images/cloud9/2/2.png?width=90pc)

3. At the Terminal interface, type the following command to know the directory path we are working in.

```
pwd
```

  + The result of the above command shows that our default working directory path is **/home/ec2-user/environment/**.
![Cloud9](/images/cloud9/2/3.png?width=90pc)

4. Type the command below to list the files in the current directory path.

```
ls
```
![Cloud9](/images/cloud9/2/4.png?width=90pc)

And there are many more Linux commands you can do on Cloud9. Linux is used a lot in Cloud Journey labs, take the time to learn about Linux if you do not have much experience working on Linux.