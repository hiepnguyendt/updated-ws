+++
title = "Sử dụng command line"
weight = 1
chapter = false
pre = "<b>3.1 </b>"
+++

#### Sử dụng command line

Trong bước này chúng ta sẽ sử dụng giao diện terminal và thực hiện các command line Linux cơ bản trên Cloud9 instance.

1. Tại giao diện IDE của Cloud9, click biểu tượng dấu +.
  + Click **New Terminal**.

![Cloud9](/images/cloud9/2/1.png?width=90pc)

2. Chúng ta sẽ thấy Cloud9 mở ra một giao diện terminal cho phép chúng ta thực hiện các command Linux.

![Cloud9](/images/cloud9/2/2.png?width=90pc)

3. Tại giao diện Terminal, gõ câu lệnh sau để biết đường dẫn thư mục chúng ta đang làm việc.

```
pwd
```

  + Kết quả câu lệnh trên cho thấy đường dẫn thư mục làm việc mặc định của chúng ta là **/home/ec2-user/environment/**.

![Cloud9](/images/cloud9/2/3.png?width=90pc)

4. Gõ câu lệnh dưới đây để liệt kê danh sách file trong đường dẫn thư mục hiện tại.

```
ls
```

![Cloud9](/images/cloud9/2/4.png?width=90pc)

Và còn rất nhiều command trên Linux nữa bạn có thể thực hiện trên Cloud9. Linux được sử dụng rất nhiều trong các bài lab của Cloud Journey, hãy dành thời gian để tìm hiểu về Linux nếu bạn chưa có nhiều kinh nghiệm làm việc trên Linux nhé.