+++
title = "Quay lại giao diện Dashboard"
weight = 3
chapter = false
pre = "<b>3.3 </b>"
+++

#### Quay lại giao diện Dashboard

Khi chúng ta tạo Cloud9, giao diện làm việc sẽ được chuyển tiếp tới Cloud9 IDE trên trình duyệt. Trong bước này, chúng ta sẽ quay lại giao diện AWS management console để làm việc với các dịch vụ khác.

1. Tại giao diện Cloud9 IDE.
  + Click biểu tượng Cloud 9.
  + Click **Go To Your Dashboad**.

![Cloud9](/images/cloud9/2/9.png?width=90pc)

2. Đôi khi giao diện Cloud9 sẽ thay đổi một chút theo trình duyệt, bạn có thể dùng cách thay thế khác để quay trở về giao diện AWS management console.
  + Click vào biểu tượng user ở góc phải giao diện Cloud9 IDE.
  + Click **Go To Dashboard**.

![Cloud9](/images/cloud9/2/10.png?width=90pc)

3. Một tab mới sẽ được mở ra và chúng ta sẽ quay lại giao diện quản trị của AWS Cloud9. Từ đây chúng ta có thể truy cập tới giao diện quản trị của các dịch vụ AWS khác.

![Cloud9](/images/cloud9/2/11.png?width=90pc)

Tiếp theo chúng ta sẽ thử chạy các câu lệnh AWS CLI trên Cloud9 nhé.