+++
title = "Back to Dashboard interface"
weight = 3
chapter = false
pre = "<b>3.3 </b>"
+++

#### Back to Dashboard interface

When we create Cloud9, the interface will be forwarded to Cloud9 IDE in the browser. In this step, we will return to the AWS management console interface to work with other services.

1. At the Cloud9 IDE interface.
  + Click the Cloud 9 icon.
  + Click **Go To Your Dashboad**.

![Cloud9](/images/cloud9/2/9.png?width=90pc)

2. Sometimes the Cloud9 interface will change slightly by browser, you can use another alternative to return to the AWS management console interface.
  + Click on the user icon in the right corner of the Cloud9 IDE interface.
  + Click **Go To Dashboard**.

![Cloud9](/images/cloud9/2/10.png?width=90pc)

3. A new tab will open and we will return to the AWS Cloud9 administration interface. From here we can access the admin interface of other AWS services.

![Cloud9](/images/cloud9/2/11.png?width=90pc)

Next we will try to run AWS CLI commands on Cloud9.