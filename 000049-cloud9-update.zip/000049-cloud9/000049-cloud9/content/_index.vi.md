+++
title = "Bắt đầu với AWS Cloud 9"
date = 2020-04-18T00:38:32+07:00
weight = 1 
chapter = false
+++

# Bắt đầu với AWS Cloud 9

#### Tổng quan

AWS Cloud9 là một môi trường phát triển tích hợp, hay còn gọi là IDE. Cloud9 có thể hoạt động ngay trực tiếp trên trình duyệt web của bạn.

AWS Cloud9 IDE cung cấp trải nghiệm chỉnh sửa mã phong phú với sự hỗ trợ cho một số ngôn ngữ lập trình và runtime debugger cùng giao diện terminal tích hợp. Cloud9 đi kèm các công cụ mà bạn sử dụng để viết mã, xây dựng, chạy, kiểm tra và gỡ lỗi phần mềm, đồng thời giúp bạn phát hành phần mềm lên đám mây.

Bạn truy cập AWS Cloud9 IDE thông qua trình duyệt web. Bạn có thể cấu hình IDE theo sở thích của mình. Bạn có thể chuyển đổi chủ đề màu sắc, liên kết các phím tắt, bật định dạng mã và tô màu cú pháp dành riêng cho ngôn ngữ lập trình, v.v.

Cloud9 sẽ được sử dụng khá thường xuyên trong các bài lab của Cloud journey, vì vậy trong bài lab này chúng ta sẽ học các thao tác cơ bản nhất khi làm việc với Cloud9.

![Cloud9](../images/serviceicon.png?featherlight=false&width=10pc)

#### Nội dung

1. [Tạo Cloud9 instance](1-createcloud9/)
2. [Thao tác cơ bản](2-basicfeature/)
3. [Sử dụng AWS CLI](3-useawscli/)
4. [Dọn dẹp tài nguyên](4-clearresource/) 

