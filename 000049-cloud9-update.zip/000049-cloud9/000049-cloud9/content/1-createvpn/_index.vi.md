+++
title = "Tạo VPN"
weight = 1
chapter = false
pre = "<b>1. </b>"
+++

#### Tạo VPN

1. Trong giao diện VPC

   - Chọn **Your VPCs**
   - Chọn **Create VPC**

![Create VPC](/images/cloud9/1/0.png?featherlight=false&width=90pc)

2. Chọn **Create VPC**

![Create VPC](/images/cloud9/1/1.png?featherlight=false&width=90pc)

3. Tạo VPC thành công và chọn View VPC

![Create VPC](/images/cloud9/1/2.png?featherlight=false&width=90pc)

4. Thực hiện cấp phát IP public.
   - Chọn **Subnets**
   - Chọn **public subnet**
   - Chọn **Edit subnet settings**

![Create VPC](/images/cloud9/1/3.png?featherlight=false&width=90pc)

5. Chọn **Enable auto-assign public IPv4 address**

![Create VPC](/images/cloud9/1/4.png?featherlight=false&width=90pc)
