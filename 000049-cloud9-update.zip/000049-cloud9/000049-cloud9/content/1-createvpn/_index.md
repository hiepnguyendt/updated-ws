---
title : "Create VPC"
date : "`r Sys.Date()`"
weight : 1
chapter : false
pre : " <b> 1 </b> "
---

#### Create VPC

1. In the interface VPC.

   - Choose **Your VPCs**
   - Select **Create VPC**

![Create VPC](/images/cloud9/1/0.png?width=90pc)

2. Select **Create VPC**
- Choose **VPC and more**
- Name tag as **cloud9-vpn**
![Create VPC](/images/cloud9/1/1.png?width=90pc)

3. Create VPC successfully and select View VPC

![Create VPC](/images/cloud9/1/2.png?width=90pc)

4. Implement public IP allocation.

   - Select **Subnets**
   - Select the **public subnet**
   - Select **Edit subnet settings**

![Create VPC](/images/cloud9/1/3.png?width=90pc)

5. Select **Enable auto-assign public IPv4 address**

![Create VPC](/images/cloud9/1/4.png?width=90pc)