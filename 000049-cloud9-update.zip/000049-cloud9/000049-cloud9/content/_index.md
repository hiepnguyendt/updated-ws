+++
title = "Getting Started with AWS Cloud 9"
date = 2020-04-18T00:38:32+07:00
weight = 1
chapter = false
+++

# Get started with AWS Cloud 9

#### Overview

AWS Cloud9 is an integrated development environment, or IDE. Cloud9 can work right in your web browser.

The AWS Cloud9 IDE provides a rich code editing experience with support for several programming languages ​​and runtime debuggers and a built-in terminal interface. Cloud9 comes with the tools you use to code, build, run, test, and debug your software, and helps you release it to the cloud.

You access the AWS Cloud9 IDE through a web browser. You can configure the IDE according to your preferences. You can switch color themes, bind keyboard shortcuts, enable code formatting and programming language-specific syntax coloring, and more.

Cloud9 will be used quite often in Cloud journey labs, so in this lab we will learn the most basic operations when working with Cloud9.

![Cloud9](../images/serviceicon.png?featherlight=false&width=10pc)

#### Content

1. [Create Cloud9 instance](1-createcloud9/)
2. [Basic Operation](2-basicfeature/)
3. [Using AWS CLI](3-useawscli/)
4. [Resource Cleanup](4-clearresource/)